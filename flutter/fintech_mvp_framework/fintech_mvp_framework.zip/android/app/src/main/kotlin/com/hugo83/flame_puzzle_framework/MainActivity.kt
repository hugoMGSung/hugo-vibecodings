package com.hugo83.flame_puzzle_framework

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
